# VEBLEN — BRAND DATA (raw material only)

Data for branding/presentation work done elsewhere. No styling here. Public-safe: contains nothing private.
Rule inherited from MASTER §0.5: **honesty over polish** — every claim below is tagged PROVEN / IN PROGRESS / VISION. Never move a claim up a tier in public copy until reality moves first. This honesty is itself part of the brand: it is what converted a LinkedIn post into two expert collaborations.

## 1. Name

Double reference, both intentional layers of the manifesto:
- **Thorstein Veblen** — economist; "conspicuous consumption", Veblen goods (desirability rises with price; luxury fashion is the purest case). Veblen criticized complexity that exists only for display. VEBLEN-the-system is the antidote: a Veblen good whose complexity is computed, body-driven, and functional. Luxury justified by geometry, not scarcity.
- **Oswald Veblen** — Princeton geometer (projective geometry, topology). The mathematics half.
- One line: *the economics of desire + pure geometry — the two halves of the system.*

## 2. What it is (approved phrasings)

- Shortest: **A computational garment system. Garments generated from the body outward.** (already used as on-screen tagline)
- Short: VEBLEN turns a measured body and a generative fold-and-cut surface into fabrication-ready garment patterns — in the browser.
- Medium: VEBLEN is two systems merged: a parametric body built from real measurements, and a surface engine that folds and cuts flat cloth into complex geometric structures (pleats, origami tessellations, kirigami, tailoring darts). Every point of the pattern knows its exact address on the body. Output: SVG / DXF / JSON for pattern software and physical fabrication.
- Motto: **one surface, one system, one body.**
- Sharpened (2026-08-11): **VEBLEN takes a body and a target ease and SUGGESTS the valid, buildable, wearable parameter window — placement included. It kills slider-guessing.** You say "hangs from the hip, +5 cm ease"; it places the garment on the measured body, sizes the cloth, sets the pleat — and shows the whole window of valid choices, not one guess. **[PROVEN for knife pleat; other techniques pending — do not generalize in public copy]**

## 3. Positioning (the empty seat)

- CAD/simulation (CLO3D, Browzwear, Optitex): simulate finished patterns; not generative — pleats are drawn by hand.
- Parametric pattern tools (GarmentCode/ETH, Seamly2D): start from classic tailoring blocks, not a generative form language.
- Pleating ateliers (Miyake lineage): fabrication mastery, no computational tool.
- **VEBLEN sits between all three: generative form language + measured body → feeds CLO and the atelier.** Not a CLO competitor; its upstream layer.

## 4. Differentiators (tagged)

1. Fold & cut techniques as first-class parametric primitives — 17 folds + 6 cuts, live sliders, instant crease pattern. No garment CAD ships this. **[PROVEN — running, on video]**
2. Full provenance: every 2D pattern point knows its (angle, height) address on the body. Basis of real made-to-measure. **[PROVEN as architecture; IN PROGRESS as validated fit]**
3. Generation direction is inverted: from body measurements outward, not from standard blocks toward fit. **[PROVEN as architecture]**
4. Browser-native, no install, shareable as a link; deterministic exports (mirrored CPU/GPU math). **[PROVEN]**
5. Quantified digital↔physical loop: pattern → CLO simulation → sewn sample → measured deviation. **[IN PROGRESS — the current phase; do not claim done]**
6. Fabrication feasibility matrix: technique × material × process validity encoded in the system. **[IN PROGRESS — v0.1 exists in MASTER §6]**
7. Inverse design: body + target ease + anchor band → valid buildable params + placement, with the full valid window shown (cloth range, max pleat depth). Exact length-preserving fold math underneath, honest per-band ease report. **[PROVEN — knife pleat only; Miura et al. pending]**
8. Discovered design law: a knife pleat without overlap has a hard contraction floor of **√(2d−1)** (d = face/return split) — the cloth can never cover less than that fraction of its width; deeper reduction requires overlap folds. Found and numerically verified while porting the exact math; feeds the feasibility matrix. **[PROVEN — verified numerically, 2026-08-11]**

## 5. Vision (3 phases — safe to state publicly as intent)

1. **Prove** (now): one computed surface → one CLO-validated → one sewn garment, deviations measured. Hero A: Miura-pleated wrap skirt, heat-set polyester.
2. **Repeat**: multiple garments, multiple bodies, documented tolerances; per-panel techniques; material library.
3. **Platform**: measurements in → fabrication-ready package with quantified fit out; atelier tooling + API for brands. Each garment ships with a "geometric passport" (pattern, crease map, measurements, measured deviation) — what separates a computational Veblen good from an expensive dress.

## 6. Proof points / traction (all real, citable)

- Working v1 engine + merged atelier (video exists): skinned measured body (13k verts / 92k particles), 17+6 technique library, SVG/DXF/JSON export.
- Launch post: ~584 impressions, organic; converted into two expert collaborations:
  - Alberto Ravelo (Doctor of Design, Miami Fashion Institute) — validation methodology advisor; proposed a joint quantitative experiment.
  - Cypress Rollins (bespoke tailor / patternmaker / technical designer, CLO3D) — agreed to CLO import + feedback now, physical prototype in studio from mid-September if simulation looks right.
- Honest-process narrative: publicly stated non-tailoring background and AI-driven implementation; it attracted expertise instead of repelling it.
- Builder profile: computational designer (fashion, sound, data); directs product/interaction/visual systems, implements via Claude Code. (Frame as a *new kind of authorship* — director + AI implementation — not as a gap.)

## 7. Audiences & messages

| Audience | Message core |
|---|---|
| Pattern makers / garment technologists | "The system speaks your formats (DXF, measurements, crease maps) and wants your constraints embedded early, not at the end." |
| Computational fashion researchers | "Provenance-first pipeline + open validation experiment; aligned with GarmentCode / smocking / developability literature (IGL ETH)." |
| Creative-tech studios / WebGL scene | "A full garment system living in the browser; parametric everything; premium studio aesthetic." |
| Investors / infrastructure (incl. Firebird-type) | "Fashion-tech's missing generative layer; browser-native; validated-loop moat (feasibility matrix + measured tolerances); made-to-measure at compute scale." |

## 8. LinkedIn post #2 — ingredients (the "serious" update)

Structure (keep to this order, honest tags apply):
1. **What happened since the launch post** — merged the two systems; real measured body with landmark rings; cloth sim started; first dressing test failed at the support layer *and why that failure was useful* (support/closure is now part of the spec). Failure-as-data is the established voice — keep it.
2. **What VEBLEN is now** — §2 medium phrasing + positioning line (§3).
3. **The current experiment** — Hero A: one Miura-pleated skirt; body validated against measurements at landmarks; DXF into CLO3D (with a named collaborating patternmaker, if Cypress agrees to be named); physical sample; measured deviation. This is the concrete, dated, falsifiable part that makes the post "the most serious one yet".
4. **The system behind it** — one paragraph on the feasibility matrix idea (technique × material × process) as the product's brain.
5. **Open call** — pattern makers, textile fabrication, computational fashion researchers, studios; plus explicitly: infrastructure/compute partners (bridge for Firebird outreach).
6. Link + tags (existing set: #ComputationalDesign #FashionTech #WebGL #ThreeJS).

Do NOT include: AAMA claims, "fabrication-ready" claims, tolerance numbers that don't exist yet, or the idealized-platform pitch as if built.

## 9. Firebird outreach (context + angle)

- Fact base: Firebird opened the region's largest AI Factory in Armenia (NVIDIA planned investment; CoreWeave earlier); ambition: 2GW+ global AI infra by end of 2028; positioning: "world-class AI infrastructure to frontier markets".
- Mo's angle: **Yerevan-based computational designer building a real product with AI as the implementation layer** — a live local case of what their infrastructure narrative promises ("frontier-market builders"). Not asking; showing. Outreach happens "with full hands": after post #2 is live and the Hero A package exists.
- One connection already made (short intro message sent); no dependency on their reply — the plan is to make the work findable and let inbound happen.
- Parallel asset: a music instrument release with a personal statement (Mo's other track record: interactive sound tools) doubles as introduction-of-method and potential project funding. Same authorship story, second proof.

## 10. Voice guardrails (for whoever styles this)

- Confident about the system, humble about the craft not yet mastered — this exact mix is what worked in every public exchange so far.
- Specific numbers over adjectives (17 techniques, 92k particles, 584 impressions — not "cutting-edge").
- Failures stated plainly and framed as data.
- Never "revolutionary / disrupting fashion". The word bank is: computed, measured, validated, provenance, tolerance, body-first.
