# VEBLEN — CONCEPT (the whole idea, one page)

Purpose: so no concept ever has to be rebuilt through multiple rounds of Q&A again.
This is the reference map. If a discussion drifts, come back here. Read alongside VEBLEN-MASTER.md.

---

## The one-line idea

A **single flat surface** becomes a **garment** through **folds and cuts alone** — wrapped onto a **measured body** — and never re-cut into sewing panels. One piece of cloth in, one garment out.

## The pipeline (the graph)

```
   ONE FLAT SURFACE                    (the only raw material)
          │
          ▼
   FOLD + CUT ENGINE                   (17 folds + 6 cuts, parametric)
          │                            folds/cuts ARE the shaping —
          │                            they absorb the body's double
          │                            curvature instead of sewn darts
          ▼
   WRAP ONTO MEASURED BODY             (every surface point knows its
          │                             address on the body = provenance)
          ▼
   ONE-PIECE GARMENT                   (the folded, wrapped surface IS
                                        the garment — no secondary pattern)
```

## The one hard problem (everything hinges on this)

```
   NOW: approximate folds          ──►     GOAL: real folds
   Folds are display effects.              Length-preserving folds that
   System SHOWS the wrap but               GUARANTEE the folded sheet
   can't GUARANTEE the sheet               lands on the measured body.
   truly fits — it may sag or              Then the output is honest.
   strain in reality.
```

This gap is *the* engineering task. Not "export a DXF". The current export is a **crease map** (a rectangle with fold lines drawn on it), not yet a real garment surface with a guaranteed fit. Making the folds length-preserving is what turns VEBLEN from "shows a wrap" into "proves a wrap".

**Status 2026-08-11 — closed for the knife pleat.** The knife pleat now runs exact rigid-panel, length-preserving math in every copy of the engine, and on top of it the system does **inverse design**: pick the band the garment hangs from + a target ease, and it places the garment on the measured body and hands back the valid, buildable parameter window (cloth width range, pleat depth ceiling) instead of slider-guessing. One discovered law along the way: a no-overlap knife pleat has a hard contraction floor of **√(2d−1)** (d = face/return split) — coverage reduction beyond that needs overlap folds. Miura and the rest of the library are still preview-approximate; the same mechanism extends to them next. Drape stays CLO3D's job by design — the engine proves the geometry, CLO proves the fall.

## Why a flat surface can't just wrap a body (the law behind it all)

A flat sheet has zero Gaussian curvature. A body (bust, hip, shoulder) has positive Gaussian curvature — it curves in two directions at once. You cannot lay a flat sheet on a doubly-curved surface without one of: **wrinkling, stretching, or removing a wedge.** This is geometry, not a bug (documented across the ETH developability papers — MASTER §8).

Classical tailoring removes wedges by **cutting**: darts, gores, sewn panels.
VEBLEN's bet: **the folds and cuts absorb the curvature instead.** A Miura tessellation gathers material in two directions; a kirigami cut opens to take curvature; a pleat stores length. The fold pattern does the dart's job — in-plane, on one surface. This is why the technique library was the point from the start, not decoration.

## Lineage (this is a real school, not a novelty)

Zero-waste / one-piece garments: kimono, sari, and above all **Issey Miyake A-POC ("A Piece Of Cloth")**. VEBLEN is A-POC with a computational geometry engine and a validation loop. Material choice (heat-set polyester) is the Miyake pleating convention — deliberately in that lineage.

## What the collaborators are FOR (so the goal never shrinks to "a skirt")

- The three Hero skirts and Cypress/CLO are a **one-time proof** that the engine's geometry is real and sewable — a human expert confirming the folded surface tells the truth.
- Once confirmed, VEBLEN **has a validated engine** and can generate other complex forms without needing a tailor each time.
- Alberto = methodology observer (body-validation, quantitative comparison). Cypress = executor (CLO import, physical sample). Neither is the destination.
- **The destination is the validated, generalizable engine** — the thing that reliably turns any complex fold/cut surface into a garment that provably fits.

## Open question the experiment will answer (state honestly)

Whether *every* form is achievable with zero cutting, or whether some highly-curved bodies still need a minimal wedge. "Which forms are truly one-piece vs. need a minimal cut" is a research result, not a failure — and it feeds the fabrication feasibility matrix (MASTER §6).

## What this means for the build (why the queue changed)

The build is no longer "generate a flat pattern and write DXF". It is:
1. Validate the body against its measurements (ground truth for fit).
2. Move folds from approximate → length-preserving, so the wrap is guaranteed, and derive the real garment surface (not the rectangle crease-map).
3. Only then export (DXF/crease map) and hand three forms to Cypress as proof.

The visual tool for changing parameters already exists (Surface Studio / atelier). This work makes what that tool *shows* become true, and makes its *output* a real garment surface rather than a decorated rectangle.
