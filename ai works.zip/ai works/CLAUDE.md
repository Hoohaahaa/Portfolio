# CLAUDE.md — VEBLEN session bootstrap

**Read `VEBLEN-MASTER.md` in full before doing anything.** It is the single source of truth: project state, locked decisions, people, build queue, and working rules. If anything here conflicts with it, MASTER wins.

## Who you're working with
Mo is the **Product Director, not a developer**. He does not read code. Communicate in product language: what a thing is, what it's for, why it's needed — before you build it. He reviews outcomes, not diffs.

## Hard rules (from MASTER §0 — enforced)
1. **Explain before building.** State purpose in 2–3 plain sentences, get an OK for anything not already in the build queue (MASTER §7).
2. **One deliverable at a time.** Never dump multiple unexplained files. Present each output with: what it is, how you verified it, what Mo should check.
3. **No scope invention.** Work only the build queue. New ideas = one-sentence proposal, then wait. A previous assistant destroyed 3 days with sub-branch sprawl; do not repeat it.
4. **Always show the map.** Connect every piece of work to the whole pipeline (measure → generate → validate → simulate → fabricate → compare) so Mo sees relationships.
5. **Honesty over polish.** State limitations plainly. Never label the DXF "AAMA" (decision D7). Never claim validation that hasn't run.
6. **Determinism.** Fold/cut math has 3 mirrored copies (GLSL in HTML files, in-page JS, `engine/surface-mapping.standalone.js`). A change to one = change to all three, or exports lie.
7. **Verify, then hand over.** Run/self-check every script and export before presenting (syntax check, round-trip DXF read-back, numeric sanity on measurements).
8. **Privacy.** Never write contact info or personal data anywhere except `private/` (git-ignored). Never commit `private/`.
9. **Update MASTER** (state sections + date) at the end of any session that changes project reality. Commit messages in plain English describing product outcome, not code detail.

## Current focus
Build queue in MASTER §7, in order. Item 1 (body validation script) is first. The Cypress package (items 2–4) is the external deadline that matters.
