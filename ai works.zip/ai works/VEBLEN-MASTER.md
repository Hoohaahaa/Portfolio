# VEBLEN — MASTER

**Single source of truth.** Any AI session (Claude Code, claude.ai, anything else) and any collaborator starts here. If a statement conflicts with this file, this file wins until Mo updates it.
Last updated: 2026-08-10 · Maintainer: Mo Shahmohamadi (Product Director)

---

## 0. Rules for any AI session working on VEBLEN

These are non-negotiable working rules set by Mo:

1. **Mo is the Product Director, not a developer.** He defines product logic, interaction, visual system and behavior. He does not read or write code. Explain everything in product language; code details only when he asks.
2. **Explain before building.** Before creating anything, state: what it is, what it's for, why it's needed. No surprise file dumps. One deliverable at a time unless Mo asks for a batch.
3. **No scope sprawl.** Do not invent sub-projects, side-quests, or "improvements" beyond the build queue (§7). If something new seems needed, propose it in one sentence and wait for approval. (Context: a previous AI assistant spawned so many sub-branches over 3 days that the project direction was lost. Never repeat this.)
4. **Show the whole map.** Mo thinks in systems, not steps. When presenting work, always connect it to the full pipeline so relationships stay visible. But *building* stays scoped.
5. **Honesty over polish.** VEBLEN's credibility with collaborators was earned by admitting limits (see §2 "not built / failed"). Never overclaim in any text written for Mo — no "expert vibe", no idealized version of the project or of Mo. If unsure, say so and ask.
6. **When in doubt, ask Mo.** Confirmation is cheaper than rework.
7. **Keep this file updated.** Any session that changes project state must update the relevant section and note the date.
8. **Determinism rule.** Fold/cut math exists in mirrored copies — in reality **five sites**, not three: atelier GLSL + atelier JS (veblen-atelier.html), SURFACE-STUDIO GLSL + JS, and the standalone lib (surface-mapping.standalone.js). Any math change must update **all five** with identical text, or exports lie. (Count corrected 2026-08-11 during the knife-pleat port; all five verified numerically equal.)
9. Mo's personal data is not stored in AI accounts. Contact details for collaborators live only in the private layer (§10), never in public copies of this repo.
10. **Copyright & licensing (hard rule).** Build everything **independently, from general geometry principles.** The ETH/IGL papers (§8) are for **inspiration and methodology only** — never copy their text, figures, or code verbatim. Before using **a single line** of any external code, **check its license**; if it is not clearly compatible with our use, do not use it — write it ourselves instead. Anything that ends up license-bound (a dependency, a borrowed snippet, a dataset) must be **labelled in this MASTER**: which file, which license, why it is allowed (§11). Default assumption: our own clean-room implementation.

## 1. What VEBLEN is

A computational garment system that generates garments **from the body outward**: a measured parametric body + a generative surface engine (folds, cuts, pleats) + point-to-point pattern↔body mapping (provenance) + fabrication export (SVG / DXF / JSON), running fully in the browser (Three.js / WebGL2).

Position in the landscape: VEBLEN sits **upstream of CLO3D**, not against it. CAD/simulation tools (CLO, Browzwear) simulate finished patterns but are not generative; parametric pattern tools (GarmentCode, Seamly2D) start from classic tailoring blocks, not from a generative form language. VEBLEN is the missing layer: generative fold/cut form language + measured body → input for CLO and the atelier.

**What the product now does (2026-08-11, knife-pleat proven):** body + target ease in → valid, buildable, wearable parameters + placement out. Pick the band the garment hangs from and the ease you want; the system places the garment on the solved body, finds the governing band, and fills cloth width / pleat depth from the exact length-preserving math — showing the whole valid window, not one guess. This is the "from the body outward" thesis made real. Knife pleat only so far; other techniques still preview-approximate.

Motto: **one surface, one system, one body.**
Name: double reference — Thorstein Veblen (Veblen goods, critique of ornamental complexity; VEBLEN is its antidote: complexity that is computed, body-driven, functional) and Oswald Veblen (geometer). Economics of desire + pure geometry = the two halves of the system.

## 2. Current state — honest

**Built and working (v1.0, confirmed running):**
- SURFACE-STUDIO.html — parametric fold & cut engine. 17 fold techniques + 6 cut types (full list: TECHNIQUES.md), all uniform-driven, instant sliders, crease-map painter, GSAP cinematic flat→fold→wrap, JSON export + live `window.SURFACE` API (contract: API-CONTRACT.md).
- veblen-atelier.html — merged system: real skinned body mesh (13,380 verts / 26,756 tris / 92,000 particles) with per-measurement morphs (bust, underbust, waist, hip, thigh, calf, neck, shoulder…), **landmark vertex rings ("bands") per measurement**, measurement curves, joint skeleton, garment surface mapped onto the body, SVG + DXF crease-pattern export (mm units), JSON export.
- Basic cloth simulation: stretch/bending + rigid collision working (moved beyond pure geometric wrapping).
- Public traction: LinkedIn launch post (~584 impressions) brought two qualified collaborators (§5).

**Known limitations (documented, not hidden):**
- Folds are **analytic displacement fields**, not isometric/rigid-panel origami. Correct-looking and parametric, but lengths are approximate at high amplitude; contraction is a slope-based estimate. **Exception (2026-08-11): KNIFE PLEAT contraction is now EXACT** — rigid-panel, length-preserving, amplitude clamped to the buildable maximum — in all five math sites (§0.8), so the fit panel and FIT button are honest for knife pleat. All other techniques still use the slope estimate; the fold *shape* on canvas is still a displacement preview for all techniques including knife pleat.
- Cuts are mask + displacement, not remeshed topology. Cut *paths* are exportable; post-cut 3D shape prediction is not reliable.
- DXF export exists but is **not validated in any garment CAD**. Not DXF-AAMA. Do not label it AAMA until Cypress confirms a clean CLO3D import.
- **The export today is a CREASE MAP, not a sewing pattern.** What comes out (SVG/DXF) is a flat rectangle with fold lines (and cut/dart lines) drawn on it — *where to fold*, not a ready-to-sew panel set. It is not the real folded garment surface, and it carries none of what a patternmaker checks first (below). Do not call it a "pattern" in any collaborator-facing text; call it a crease map. (CONCEPT: a "decorated rectangle", not a garment surface.)
- Patterns lack seam allowance, closed-dart geometry, grainline, notches — the items a patternmaker checks first.
- Body mesh **not yet validated** against input measurements at landmarks (Alberto's point; fix = build queue item 1).
- Single-panel wrap model; real garments are multi-panel (roadmap).
- **REST-POSE wrap, no drape — and that boundary is deliberate.** The canvas garment follows the body's radius everywhere (body radius + skin offset + fold), so it clings under the hip instead of falling free. There is no gravity/woven-physics solver and none is planned in-engine: free-fall drape is **CLO3D's job** when Cypress imports the flat pattern (D6). The DXF/SVG export carries the true flat sheet, so the drape stage receives honest geometry.
- Default coverage is now **360°** (full wrap; was 306°).

**Failed (useful data, keep visible):**
- First "Hero A" dressing test with cloth sim failed at the **support/attachment layer** (garment doesn't stay up on its own). Makes the next problem explicit: waistband/closure/support must be part of the garment spec, not an afterthought.

## 2A. The core technical goal — make the fold real (the one that makes the output honest)

Today's folds are **approximate analytic displacement fields**: correct-looking and parametric, but **length is not preserved**, so the folded sheet is not guaranteed to be a real, buildable surface — in reality it may sag or strain, and the wrap is *shown*, not *proven* (see §2 limitations, and CONCEPT "the one hard problem").

**The goal: move folds to DISCRETE ISOMETRIC (rigid-panel) folds.** Flat rigid facets joined at creases that bend but do not stretch → total surface length is preserved. When length is preserved, the folded surface is a **real** surface and the wrap onto the measured body is **guaranteed**, not merely displayed. Only then is the export an honest garment surface instead of a decorated rectangle (§2).

Scope of this goal — **locked**:
- **Target now = discrete rigid-panel folds for the three Hero skirts.** Knife Pleat and Miura-ori are rigid-panel **exact** (flat-foldable, length-preserving by construction). Bias Twist Spiral (technique 16) **may stay approximate** — **flag it honestly** wherever it appears; it is not claimed as isometric.
- **NOT now = full, mathematically-proven isometric folding.** General isometry proofs, curved-fold kinematics, guaranteed developability for any technique = a **later research phase**, explicitly out of scope for the Hero proof. Do not attempt it now.

This reframes the build (see §7 and CONCEPT "what this means for the build"): the job is not "write a DXF", it is "make the fold real, then the DXF tells the truth."

## 3. Locked decisions

| # | Decision | Value |
|---|---|---|
| D1 | Hero A garment | Pleated wrap skirt |
| D2 | Technique | MIURA-ORI (technique 04) — complex Surface-Studio form with exact analytic flat pattern and a proven physical route (paper mold + heat-set). Fallback if a rotational form is wanted: BIAS TWIST SPIRAL (16) |
| D3 | Cut layer | TAILORING DARTS (cut 06) for waist–hip difference + rectangular waistband (also answers the failed support test) |
| D4 | Material | 100% polyester, lightweight (~70–100 gsm) — standard heat-set pleating substrate (Miyake-line convention) |
| D5 | Reference measurements | Atelier defaults (≈ size M): bust 83.3 / underbust 66.6 / waist 71.8 / hip 95.3 / thigh 51.4 / calf 35.6 cm. Mo: exact values not critical for v1 |
| D6 | CLO3D expectation | CLO validates the **garment** (fit, silhouette, seams, darts) with simplified pleat representation; the full Miura tessellation is realized by the physical mold, not simulated. Stated explicitly in the Cypress spec sheet |
| D7 | Export label | Regular DXF until AAMA import is verified |
| D8 | Repo | github.com/Hoohaahaa/VEBLEN — single source of truth; this file lives at its root |

## 4. Mo — position and profile

- Computational Designer (public headline: "building interactive tools for fashion, sound, and data"). Stack identity: WebGL2 / Three.js / GLSL / GSAP / Web Audio / real-time data / particle systems — **executed via Claude Code**, not hand-written. Mo openly states this to collaborators; it has cost nothing and earned trust.
- Role in VEBLEN: **Product Director.** Owns concept, direction, form language, visual system, quality bar, relationships, and brand. Delegates implementation to AI, garment expertise to collaborators.
- Working style: needs the whole picture at once with visible relationships; step-by-step drip-feeding without the map does not work for him. Catches the smallest inconsistency ("ریزترین فالش") — treat his review as QA.
- Not: a developer, a patternmaker, a garment technologist. Do not write text that pretends otherwise, and do not write text that needs that expertise to be understood.
- Resources: independent, very limited budget/time. Strategy: small but meaningful experiments; collaborators close the expertise gap.
- Location context: Yerevan, Armenia. Relevant only as ecosystem (see BRAND-DATA: Firebird outreach).

## 5. People — do not confuse them

| Person | Role | Gets | Never |
|---|---|---|---|
| **Alberto Ravelo** (Doctor of Design, Miami Fashion Institute, BespokeTailoring.ai) | **Observer / expert advisor.** Researches digital-to-physical validation. Raised the body-validation requirement. Proposed a future joint experiment (validate body → generate → fabricate → compare) | Status **updates** only (e.g., body-validation results). Contact when methodology input is needed | Deliverable files, packages, tasks |
| **Cypress Rollins** (Bespoke tailor, patternmaker, technical designer; CLO3D; USA, traveling in Italy until mid-September) | **Executor.** Will import DXF into CLO3D while traveling and give feedback; physical prototype in studio (~mid-September) if CLO result looks realistic | The Hero A package: DXF + body measurements + crease/cut map + spec sheet. Via email (address in private layer) | Being treated as an observer; over-technical geometry talk |
| **Claude (any session)** | Implementation + analysis under rules §0 | Build queue tasks | Scope invention |

## 6. Fabrication feasibility matrix (v0.1)

Technique × material × process → status. This matrix is product IP: the layer that keeps the full form library while deciding what is *valid to fabricate*. Extend as evidence arrives; every status change needs a source (test, collaborator confirmation, literature).

| Technique family | Woven (poly, heat-set) | Woven (natural fiber) | Non-woven (felt / neoprene / Tyvek) | Knit |
|---|---|---|---|---|
| Pleats 01,02,03,10,16 (knife/box/micro/sunburst/bias-twist) | **ALLOWED** — paper mold + steam/oven heat-set; industry-proven (Miyake lineage) | CONDITIONAL — pleats don't hold without heat-set; needs stitching/starch | ALLOWED — press or stitch | FORBIDDEN (v1) |
| Origami tessellations 04,05,06,07,08,09 (Miura, Yoshimura, waterbomb, Kresling, Resch, square-twist) | **ALLOWED (Hero A path)** — dual paper mold + heat-set | FORBIDDEN (v1) | CONDITIONAL — thickness fights fold density | FORBIDDEN (v1) |
| Curved fold 11 | CONDITIONAL — curved-crease heat-set is advanced atelier craft | FORBIDDEN (v1) | CONDITIONAL | — |
| Drape/ruffle 12,13 | ALLOWED — conventional construction (no mold needed) | ALLOWED | N/A | ALLOWED |
| Smocking 14 / shibori 15 | ALLOWED — thread-based (stitch/gather); no heat-set required; strongest literature support (IGL smocking papers, physically validated) | ALLOWED | CONDITIONAL | CONDITIONAL |
| Kirigami cuts 01–05 (slits, rotating squares, petals, fractal) | **FORBIDDEN — fraying** (unless edge-sealed/bonded: CONDITIONAL) | FORBIDDEN | **ALLOWED — laser-cut** (Developable Metamaterials, CHI 2021 route) | CONDITIONAL (structured knit) |
| Darts cut 06 | ALLOWED — standard tailoring | ALLOWED | ALLOWED (stitched) | ALLOWED |

Clarification (Mo, on record): kirigami-on-woven was never the plan. The concept is a complete form library + this constraint layer deciding technique↔material↔process validity inside a validated system.

## 7. Build queue (near-term, in order)

1. **Body validation script** — slice body at landmark rings (the `bands` data already in veblen-atelier.html gives per-landmark vertex loops → measure polyline circumference after morphs), compare against input measurements, report deviation in mm. *Answers Alberto; precondition for any fit claim.* **✅ DELIVERED (2026-08-10).** `BODY VALIDATION · REPORT` button in the atelier EXPORT panel (also `window.VEBLEN.validate()`); reuses the product's own `solve()`+`girth()`; opens a colour-coded HTML report for all 7 landmarks (GREEN <0.5% or <3 mm / YELLOW 0.5–1.5% / RED >1.5%), labelling bust/underbust/waist/hip as actively-solved and thigh/calf/neck as morph-set-not-corrected, and noting between-band interpolation. At reference size M all 7 = GREEN (worst 0.03%).
2. **Analytic Miura unfold + darts** — exact flat pattern for Hero A skirt with closed boundary (pre-fold rectangle dimensions from contraction-exact math, dart wedges, waistband rectangle). *This is where §2A's rigid-panel goal is realized: Knife Pleat and Miura are length-preserving exact; Bias Twist Spiral stays flagged-approximate. Full isometry proofs are out of scope (§2A).*
   **Step 1 ✅ DELIVERED & APPROVED (2026-08-11): Knife Pleat exact mechanism.** `KNIFE PLEAT · EXACT PROOF` button in the atelier (also `window.VEBLEN.pleatProof()`); isolated proof, live engine math untouched. Findings at defaults: slope estimate said contraction 39.2% vs exact 67.6% (42.6 cm of cloth mis-estimated — explains the observed negative ease, WAIST −2.2 / HIP −22.2 → positive with exact math); displayed surface was 87% longer than the fabric (the stretch lie, now quantified); default 5.5 cm pleats are UNBUILDABLE at 16 pleats/150 cm (max sharp-crease amplitude 1.31 cm). Knife-pleat design law (verified numerically): contraction floor = √(2d−1) for face/return duty d — deeper coverage reduction than that requires overlap folds (model extension, flag honestly). Next steps in order: (a) port exact contraction into the mirrored math copies so the fit panel is honest — **✅ DELIVERED (2026-08-11)**: exact knife-pleat contraction in all **five** math sites (§0.8 count corrected), verified numerically identical (0.675962 at defaults in atelier JS, studio JS, standalone lib; GLSL textually identical ×2); fit panel now honest (defaults: all bands positive EXCESS CLOTH); FIT button verified honest (hip ease +4 requested → +4.00 achieved, W 150→125.8); proof report gap now reads 0% (regression check). (b) knife-pleat "buildable window / suggest valid params" — **✅ DELIVERED (2026-08-11)**: `SUGGEST · PLACE + SIZE` button in the FIT section (also `window.VEBLEN.suggest()`). Pick anchor band chip (waist/hip) + ease → one click places the garment on the band (hemY set from the solved body's band height), finds the governing band across the garment's span (widest need wins; others get ≥ +1), sizes cloth to mid buildable-window and inverts the exact contraction for amplitude (pleat count kept), then reports the window (cloth min-max, amp max) — not just the point. Verified: HIP+5 → placed y83, W 103.4 (window 86-130), amp 0.76 (max 0.90), achieved exactly +5.0 RELAXED; WAIST+5 → waist in-span (OUT OF SPAN fixed), governed by HIP, hip +1.0 FITTED, waist +21.0 flagged "EXCESS IS REAL · DARTS/WAISTBAND ABSORB IT (CONSTRUCTION STEP)"; non-knife techniques refused honestly. Knife pleat only (the only technique with exact math). Drape/clinging on canvas is NOT addressed and NOT (b)'s job: no woven physics by design — free-fall drape is CLO3D's role on Cypress import (D6); the DXF already carries the true flat sheet. *(Those verification numbers were at the old 306° default; coverage is now 360° — same scenarios verified again: HIP+5 → window 100-151 cm, W 120.6, amp 0.89, exact +5.0; WAIST+5 → window 96-145, W 115.8, waist excess +24.5.)* (c) Miura on the same mechanism.
3. **DXF writer + layer discipline** — 1:1 scale, cm/mm documented, boundary / internal fold lines (mountain/valley separated) / grain / notches / annotation on standard layers. Round-trip self-check. AAMA layer convention targeted but labeled "regular DXF" per D7.
4. **Cypress package** — DXF + measurement table (for CLO avatar setup) + crease/cut map SVG + one-page spec sheet PDF (material, fold logic, construction order suggestion, D6 simulation caveat). → email to Cypress.
5. *(after Cypress feedback)* corrections → physical sample → quantitative comparison (the Alberto experiment: geometric deviation, fit at key regions, support behavior, construction tolerance).

Roadmap beyond queue (not now): multi-panel / per-panel techniques, true rigid origami kinematics, DXF-AAMA validated label, body-scan input, material library expansion of §6.

## 8. Reference map — IGL ETH (igl.ethz.ch/publications)

Use for: methods, validation methodology, and credibility citations — **never verbatim text or code (see §0 rule 10; register any license-bound use in §11).** Priority order:
- **GarmentCode + GarmentCodeData (2023/24)** — reference architecture for measurements→parametric pattern; dataset useful for body validation.
- **Computational Pattern Making from 3D Garment Models (2022, code: parafashion)** — 3D surface → flattenable panels with darts/seams; the inverse-problem reference if ever needed.
- **Smocking trilogy: Digital 3D Smocking (2023), Fabric Tessellation (2024, award), Italian Smocking (2024)** — computational pleat/gather structures with physical validation; direct match to technique 14 and the honest fabric-native path.
- **Hinged Kirigami Tessellations (2025) + Uniformly Deployable Kirigami (2026)** — mathematically correct versions of cuts 01–05.
- **Developable Metamaterials (CHI 2021)** — laser-cut kirigami wearable route (non-woven).
- **Developability line: Geodesic Nets / DOG shape space (2018), Curved Folding (2019), Developable Wrapping (2020), Gauss Thinning (2021), Dev2PQ (2022)** — the math of "cloth doesn't stretch"; explains why doubly-curved regions require darts/gores/smocking (fundamental limit, not a bug).
- **Chebyshev Parameterization for Woven Fabric (2024)** — woven shear ≠ paper; future accuracy phase.
- **Rags2Riches (2025) / Garment Alteration (2024) / Dress Anyone (2025)** — pattern refit; made-to-measure phase.
- **Zippables (2018)** — conceptual kin of "one surface, one body".
- Not needed now: AIpparel / neural-motion line.

## 9. File inventory (repo root expectations)

- `VEBLEN-MASTER.md` — this file.
- `VEBLEN-CONCEPT.md` — the whole idea on one page (read alongside this file).
- `CLAUDE.md` — session bootstrap for Claude Code (reads this file first, enforces §0).
- `BRAND-DATA.md` — branding raw data (public-safe).
- `docs/` — HANDOFF.md, TECHNIQUES.md, API-CONTRACT.md (existing, unchanged).
- `engine/` — SURFACE-STUDIO.html, veblen-atelier.html, surface-mapping.standalone.js.
- `validation/` — build-queue item 1 output.
- `exports/` — build-queue items 2–4 outputs (Cypress package).
- `private/` — **git-ignored.** Contacts (Cypress email), personal notes. Never in public copies.

## 10. Private layer

Nothing personal is stored in this public file or in AI accounts. Cypress's email and any contact info live in `private/` (git-ignored) on Mo's machine only.

## 11. Licensed / external code register

Per §0 rule 10, every piece of code or data in VEBLEN that is **not** our own clean-room implementation is listed here with its source, license, and why it is allowed. If a file is not listed, it is ours.

| File / snippet | Source | License | Why allowed |
|---|---|---|---|
| MakeHuman base mesh (baked body data) | MakeHuman 1.3.0 | CC0 | Public domain; output is ours |
| _(nothing else yet — all geometry/fold/cut math is our own implementation)_ | — | — | — |

Rule: nothing gets added to this table without its license checked first. ETH/IGL papers are **not** in this table because we take only inspiration from them, never their code or text (§8).
